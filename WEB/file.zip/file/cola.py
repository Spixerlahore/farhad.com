from bs4 import BeautifulSoup
import requests
city_1 = "Berlin"
city_2 = "Bochum"
url = f"https://www.numbeo.com/cost-of-living/compare_cities.jsp?country1=Germany&country2=Germany&city1={city_1}&city2={city_2}&tracking=getDispatchComparison"
page = requests.get(url)
soup = BeautifulSoup(page.content,"html.parser")
table = soup.find("table",attrs={"class":"data_wide_table new_bar_table cost_comparison_table"})

rows = table.find_all('tr')

cola_data = rows[7].text.split()
price_1 = cola_data[4]
price_2 = cola_data[6]
print("This programm is an example of a Webscraper built with python")
print("Price in Berlin: "+ price_1)
print("Price in Bochum: "+ price_2)
